const cookieImage = document.getElementById("cookie-image");
let clickCount = 0;
const clickCountDisplay = document.getElementById("click-count");

cookieImage.addEventListener("click", () => {
  clickCount++;
  console.log(`Cookie clicked! Total clicks: ${clickCount}`);
  clickCountDisplay.textContent = clickCount;
});
